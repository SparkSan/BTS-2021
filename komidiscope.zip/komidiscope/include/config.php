<?php

require_once 'include/fonction.php'; 


    
    require_once('modele/modele.class.php');

    $spectacles = new Spectacle($DB_cnx);



?>
