
<!DOCTYPE html>
<html>
<head>
	<title>Acceil</title>
	<link rel="stylesheet" type="text/css" href="">
</head>
<body>

	<h1>BIENVENUE</h5>

	<h3>Inscription</h3>
	

	<form method="POST" action="traitementins.php">
		<input type="text" name="identifiant" placeholder="Speudo"/>
		</br>
		<input type="text" name="nom" placeholder="Nom"/>
		</br>
		<input type="text" name="prenom" placeholder="Prenom"/>
		</br>
		<input type="email" name="Email" placeholder="EMail"/>
		</br>
		<input type="password" name="mdp" id="mdp" placeholder="Mot de passe"/>
		</br>
		<input type="Submit" name="submit" value="Connection"></input>
	</form>

</body>
</html>