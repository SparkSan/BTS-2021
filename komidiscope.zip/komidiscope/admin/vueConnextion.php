<!DOCTYPE html>
<html>
<head>
	<title>Acceil</title>
	<link rel="stylesheet" type="text/css" href="">
</head>
<body>

	<h1>BIENVENUE</h5>

	<h3>Connexion</h3>
	

	<form method="POST" action="traitementins.php">
		<input type="email" name="Email" placeholder="EMail"/>
		</br>
		<input type="password" name="mdp" id="mdp" placeholder="Mot de passe"/>
		</br>
		<input type="Submit" name="submit" value="Connection"></input>
	</form>

</body>
</html>